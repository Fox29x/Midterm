import mt2
import mt3
import mt4

#above code will import your code from seperate files on the left. No need to add any code to this file.

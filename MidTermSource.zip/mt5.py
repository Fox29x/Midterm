#You will not do any coding here!

#You will create a new repl (not a file in here) using Python (with Turtle) named mt5_lastname (using your last name). mt5 will be shared separately from your first repl (this one) with your first 4 activities.

#You will create 5 squares (black outline only) that start with size 50 and grow 25% larger each time. They can all start at the same place (for simplicity). You should use one function with a for loop and nested for loop (that draws the first square), size variable should be local (in the function def), and then incremented in the function. Use one function call to run it.

#You can copy the comment above to your new repl if you like or even put it in a separate file within your repl so it is out of your way. 
from turtle import Turtle

Square = (2 ** 0.5) / 2

Geo = Turtle()
Geo.pencolor("purple")
Geo.setheading(45)
Geo.width(3)

for radius in range(25, 25 * 5 + 1, 25):
    Geo.penup()
    Geo.goto(radius/2, -radius/2)
    Geo.pendown()
    Geo.circle(radius * Square, steps=4)

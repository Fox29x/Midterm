#Convert school to a list of 4 words, then use a for loop to print the words on 4 consecutive lines.

school = "Warren County Community College"
#Your code below:
school = school.split()
for i in school:
        print (i)
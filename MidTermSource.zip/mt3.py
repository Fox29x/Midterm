#Define a function that computes batting average (hits / at bats). It should have 2 parameters (ab,h). Have the function return a value. Then call the function with the arguments (449, 175). Display the batting average with 3 decimal places ex/.326
def battavg(ab,h):
  average=h/ab
  batting = format(average, '.3f')
  print(batting)

battavg(449, 175)

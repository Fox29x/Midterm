#Create a simple while loop that counts down from 20 (by one) and prints the counter number on sepearate lines. When finished, it will print "Done!. The last number printed should be 1 before printing Done!
import time 
seconds = int(input("Amount of seconds ")) 

for i in range(seconds): 
    print(str(seconds - i)) 
    time.sleep(1) 

print ('Done!')
